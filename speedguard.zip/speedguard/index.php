<?php // Silence is golden
 